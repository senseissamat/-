# Auto Salon Package

This package helps manage car dealership operations including finance calculations and inventory formatting.